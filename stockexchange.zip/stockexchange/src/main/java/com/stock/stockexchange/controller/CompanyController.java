package com.stock.stockexchange.controller;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stock.stockexchange.model.Company;
import com.stock.stockexchange.model.Sector;
import com.stock.stockexchange.model.StockPrice;
import com.stock.stockexchange.service.CompanyService;
import com.stock.stockexchange.service.SectorService;

@RestController
@RequestMapping("/companyController")
public class CompanyController {

	@Autowired
	SectorService sectorService;

	@Autowired
	CompanyService companyService;

	
	@GetMapping("/getCompany/{id}")
	public List<Sector> getCompany(@PathVariable("id") int id) {
		System.out.println("get Company List  with sector id = " + id + "...");

		List<Sector> sectorData = sectorService.findBySectorId(id);

		return sectorData;
	}
	
	@GetMapping("/getMatchingCompany/{match}")
	public List<Company> getMatchingCompany(@PathVariable("match") String match) {
		System.out.println("get Company List  with match letters = " + match + "...");

		List<Company> matchedCompany = companyService.findByPattern(match);

		return matchedCompany;
	}

	

}
