package com.stock.stockexchange.dao;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;




import com.stock.stockexchange.model.IpoPlanned;

@Repository 
public interface IpoPlannedDao extends JpaRepository<IpoPlanned,Integer> {

	
	@Query("Select s From IpoPlanned s where s.companyCode = :companyCode")


	List<IpoPlanned> findByCompanyId(@Param("companyCode") int companyCode);
	
	
	
}
