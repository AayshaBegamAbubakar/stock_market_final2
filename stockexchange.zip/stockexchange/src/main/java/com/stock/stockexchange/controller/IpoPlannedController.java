package com.stock.stockexchange.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.stock.stockexchange.dao.IpoPlannedDao;
import com.stock.stockexchange.model.IpoPlanned;


@RestController
@RequestMapping("/ipoController")
public class IpoPlannedController {

	@Autowired
	IpoPlannedDao repository;

	@GetMapping("/getIpo/{id}")
	public List<IpoPlanned> getIPO(@PathVariable("id") int id) {
		System.out.println("get IPO  with company code = " + id + "...");

		List<IpoPlanned> ipoData = repository.findByCompanyId(id);

		return ipoData;
	}
	
	


}
