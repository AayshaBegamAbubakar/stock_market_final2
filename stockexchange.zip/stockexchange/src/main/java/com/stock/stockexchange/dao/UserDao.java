package com.stock.stockexchange.dao;

import java.sql.SQLException;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.stock.stockexchange.model.User;

@Repository
public interface UserDao extends JpaRepository<User, Integer> {
	
    @Query("Select u From User u where u.userName = :userName and u.password=:password")
	User validateUser(@Param("userName")String userName, @Param("password")String password);

    @Query("Select u From User u where u.userName = :userName and u.secretQuestion=:secretQuestion")
	User resetPassword(String userName, String secretQuestion);

	

	

}
