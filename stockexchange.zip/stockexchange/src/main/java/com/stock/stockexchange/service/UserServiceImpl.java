package com.stock.stockexchange.service;

import java.sql.SQLException;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.stock.stockexchange.dao.UserDao;
import com.stock.stockexchange.model.User;
@Service
public class UserServiceImpl implements UserService {
 
	@Autowired
	UserDao userDao;
	@Override
	public User insertUser(User user) throws SQLException {
		// TODO Auto-generated method stub
		System.out.println("afetr dao ");
		 user.setConfirmed("Yes");
		 user.setUserType("User");
		return userDao.save(user);
		
	}
	@Override
	public User validateUser( User user) {
		
		return userDao.validateUser(user.getUserName(),user.getPassword());
	}
	@Override
	public User resetPassword(User user) {
		// TODO Auto-generated method stub
		System.out.println("inside reset password service impl");
		User newUser=userDao.resetPassword(user.getUserName(),user.getSecretQuestion());
		return newUser;
	}

}
